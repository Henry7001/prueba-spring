package com.Prueba.Prueba_Spring.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Prueba.Prueba_Spring.model.Ficha;
import com.Prueba.Prueba_Spring.model.Usuario;
import com.Prueba.Prueba_Spring.repository.FichaRepository;
import com.Prueba.Prueba_Spring.repository.UsuarioRepository;

import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private FichaRepository fichaRepository;

    public Usuario registrarVigilante(Usuario usuario) {
        // Asumimos que el rol de vigilante ya está asignado al usuario
        return usuarioRepository.save(usuario);
    }

    public void asignarPabellon(Long vigilanteId, Long pabellonId) {
        Optional<Usuario> vigilanteOpt = usuarioRepository.findById(vigilanteId);
        if (vigilanteOpt.isPresent()) {
            Usuario vigilante = vigilanteOpt.get();
            vigilante.setPabellonId(pabellonId);
            usuarioRepository.save(vigilante);
        } else {
            throw new RuntimeException("Vigilante no encontrado");
        }
    }

    public void validarFicha(Long fichaId) {
        Optional<Ficha> fichaOpt = fichaRepository.findById(fichaId);
        if (fichaOpt.isPresent()) {
            Ficha ficha = fichaOpt.get();
            ficha.setValida(true);
            fichaRepository.save(ficha);
        } else {
            throw new RuntimeException("Ficha no encontrada");
        }
    }
}