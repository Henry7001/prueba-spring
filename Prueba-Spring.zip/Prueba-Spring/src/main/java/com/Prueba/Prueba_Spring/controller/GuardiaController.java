package com.Prueba.Prueba_Spring.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Prueba.Prueba_Spring.model.Celda;
import com.Prueba.Prueba_Spring.service.GuardiaService;

@RestController
@RequestMapping("/guardia")
public class GuardiaController {

    @Autowired
    private GuardiaService guardiaService;

    @GetMapping("/monitorear-celdas")
    public ResponseEntity<List<Celda>> monitorearCeldas(@RequestParam Long guardiaId) {
        List<Celda> celdas = guardiaService.monitorearCeldas(guardiaId);
        return ResponseEntity.ok(celdas);
    }
}