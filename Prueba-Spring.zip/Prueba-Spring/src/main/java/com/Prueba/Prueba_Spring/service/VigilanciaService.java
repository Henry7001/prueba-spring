package com.Prueba.Prueba_Spring.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Prueba.Prueba_Spring.model.Celda;
import com.Prueba.Prueba_Spring.model.Ficha;
import com.Prueba.Prueba_Spring.model.Recluso;
import com.Prueba.Prueba_Spring.model.Usuario;
import com.Prueba.Prueba_Spring.repository.CeldaRepository;
import com.Prueba.Prueba_Spring.repository.FichaRepository;
import com.Prueba.Prueba_Spring.repository.ReclusoRepository;
import com.Prueba.Prueba_Spring.repository.UsuarioRepository;

@Service
public class VigilanciaService {

    @Autowired
    private FichaRepository fichaRepository;

    @Autowired
    private ReclusoRepository reclusoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CeldaRepository celdaRepository;

    public Recluso ingresarRecluso(Ficha ficha) {
        fichaRepository.save(ficha);
        Recluso nuevoRecluso = new Recluso();
        nuevoRecluso.setFicha(ficha);
        return reclusoRepository.save(nuevoRecluso);
    }

    public void distribuirRecluso(Long reclusoId, Long celdaId) {
        Recluso recluso = reclusoRepository.findById(reclusoId)
            .orElseThrow(() -> new RuntimeException("Recluso no encontrado"));

        Celda celda = celdaRepository.findById(celdaId)
            .orElseThrow(() -> new RuntimeException("Celda no encontrada"));

        recluso.setCelda(celda);
        reclusoRepository.save(recluso);
    }

    public Usuario registrarGuardia(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }
}