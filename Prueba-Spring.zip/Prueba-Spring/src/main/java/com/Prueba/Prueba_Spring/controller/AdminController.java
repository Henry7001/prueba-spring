package com.Prueba.Prueba_Spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Prueba.Prueba_Spring.model.Usuario;
import com.Prueba.Prueba_Spring.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/registrar-vigilante")
    public ResponseEntity<Usuario> registrarVigilante(@RequestBody Usuario usuario) {
        Usuario nuevoUsuario = adminService.registrarVigilante(usuario);
        return ResponseEntity.ok(nuevoUsuario);
    }

    @PostMapping("/asignar-pabellon")
    public ResponseEntity<Void> asignarPabellon(@RequestParam Long vigilanteId, @RequestParam Long pabellonId) {
        adminService.asignarPabellon(vigilanteId, pabellonId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/validar-ficha")
    public ResponseEntity<Void> validarFicha(@RequestParam Long fichaId) {
        adminService.validarFicha(fichaId);
        return ResponseEntity.ok().build();
    }
}