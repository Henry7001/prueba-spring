package com.Prueba.Prueba_Spring.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Prueba.Prueba_Spring.model.Celda;
import com.Prueba.Prueba_Spring.repository.CeldaRepository;

import java.util.List;

@Service
public class GuardiaService {

    @Autowired
    private CeldaRepository celdaRepository;

    public List<Celda> monitorearCeldas(Long guardiaId) {
        // Lógica para obtener las celdas asignadas a un guardia
        return celdaRepository.findByGuardiaId(guardiaId);
    }
}