package com.Prueba.Prueba_Spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Prueba.Prueba_Spring.model.Ficha;

@Repository
public interface FichaRepository extends JpaRepository<Ficha ,Long>{
    
}