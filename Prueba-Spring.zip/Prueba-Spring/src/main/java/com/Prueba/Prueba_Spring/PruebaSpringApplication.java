package com.Prueba.Prueba_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaSpringApplication.class, args);
	}

}
