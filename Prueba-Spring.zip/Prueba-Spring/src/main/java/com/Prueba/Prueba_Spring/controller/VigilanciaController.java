package com.Prueba.Prueba_Spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Prueba.Prueba_Spring.model.Ficha;
import com.Prueba.Prueba_Spring.model.Recluso;
import com.Prueba.Prueba_Spring.model.Usuario;
import com.Prueba.Prueba_Spring.service.VigilanciaService;

@RestController
@RequestMapping("/vigilancia")
public class VigilanciaController {

    @Autowired
    private VigilanciaService vigilanciaService;

    @PostMapping("/ingresar-recluso")
    public ResponseEntity<Recluso> ingresarRecluso(@RequestBody Ficha ficha) {
        Recluso nuevoPreso = vigilanciaService.ingresarRecluso(ficha);
        return ResponseEntity.ok(nuevoPreso);
    }

    @PostMapping("/distribuir-recluso")
    public ResponseEntity<Void> distribuirRecluso(@RequestParam Long presoId, @RequestParam Long celdaId) {
        vigilanciaService.distribuirRecluso(presoId, celdaId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/registrar-guardia")
    public ResponseEntity<Usuario> registrarGuardia(@RequestBody Usuario usuario) {
        Usuario nuevoUsuario = vigilanciaService.registrarGuardia(usuario);
        return ResponseEntity.ok(nuevoUsuario);
    }
}