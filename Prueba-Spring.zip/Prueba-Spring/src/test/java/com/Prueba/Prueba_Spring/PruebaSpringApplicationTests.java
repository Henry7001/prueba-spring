package com.Prueba.Prueba_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
